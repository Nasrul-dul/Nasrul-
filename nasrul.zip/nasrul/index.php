<?php
session_start();

// ---- Koneksi database ----
$koneksi = mysqli_connect("localhost", "root", "", "nasrul");
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// ---- DATA ADMIN ----
$admin_user = "admin";
$admin_pass = "12345";

// ---- LOGOUT ----
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// ---- LOGIN ----
if (isset($_POST['login'])) {
    $user = trim($_POST['username']);
    $pass = trim($_POST['password']);

    if ($user === $admin_user && $pass === $admin_pass) {
        $_SESSION['login_admin'] = true;
        $_SESSION['pesan'] = "✅ Selamat datang, Admin!";
        $_SESSION['tipe_pesan'] = "sukses";
    } else {
        $_SESSION['pesan'] = "❌ Username atau Password salah!";
        $_SESSION['tipe_pesan'] = "error";
    }
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// ---- CEK LOGIN ----
$login = isset($_SESSION['login_admin']) && $_SESSION['login_admin'] === true;

// ---- FUNGSI ----
$edit = false;
function hanyaHuruf($teks) {
    return preg_match("/^[a-zA-Z\s]+$/", $teks);
}

// ---- Ambil pesan session ----
$pesan = isset($_SESSION['pesan']) ? $_SESSION['pesan'] : "";
$tipe_pesan = isset($_SESSION['tipe_pesan']) ? $_SESSION['tipe_pesan'] : "";
unset($_SESSION['pesan'], $_SESSION['tipe_pesan']);

// ---- CRUD BUKU (hanya kalau login) ----
if ($login) {
    // Tambah buku
    if (isset($_POST['simpan'])) {
        $judul = trim($_POST['judul']);
        $penulis = trim($_POST['penulis']);

        if (!hanyaHuruf($penulis)) {
            $_SESSION['pesan'] = "❌ Nama Penulis hanya boleh huruf dan spasi!";
            $_SESSION['tipe_pesan'] = "error";
        } else {
            $cek = mysqli_query($koneksi, "SELECT * FROM buku WHERE judul='$judul'");
            if (mysqli_num_rows($cek) > 0) {
                $_SESSION['pesan'] = "⚠️ Buku dengan judul <b>$judul</b> sudah ada!";
                $_SESSION['tipe_pesan'] = "warning";
            } else {
                mysqli_query($koneksi, "INSERT INTO buku (judul, penulis) VALUES ('$judul', '$penulis')");
                $_SESSION['pesan'] = "✅ Buku <b>$judul</b> berhasil ditambahkan!";
                $_SESSION['tipe_pesan'] = "sukses";
            }
        }
        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
    }

    // Ambil data untuk diedit
    if (isset($_GET['edit'])) {
        $id = $_GET['edit'];
        $data = mysqli_query($koneksi, "SELECT * FROM buku WHERE id='$id'");
        $row = mysqli_fetch_assoc($data);
        $edit = true;
    }

    // Update buku
    if (isset($_POST['update'])) {
        $id = $_POST['id'];
        $judul = trim($_POST['judul']);
        $penulis = trim($_POST['penulis']);

        if (!hanyaHuruf($penulis)) {
            $_SESSION['pesan'] = "❌ Nama Penulis hanya boleh huruf dan spasi!";
            $_SESSION['tipe_pesan'] = "error";
        } else {
            $cek = mysqli_query($koneksi, "SELECT * FROM buku WHERE judul='$judul' AND id != '$id'");
            if (mysqli_num_rows($cek) > 0) {
                $_SESSION['pesan'] = "⚠️ Buku dengan judul <b>$judul</b> sudah ada!";
                $_SESSION['tipe_pesan'] = "warning";
            } else {
                mysqli_query($koneksi, "UPDATE buku SET judul='$judul', penulis='$penulis' WHERE id='$id'");
                $_SESSION['pesan'] = "✅ Buku <b>$judul</b> berhasil diperbarui!";
                $_SESSION['tipe_pesan'] = "sukses";
                $edit = false;
            }
        }
        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
    }

    // Hapus buku satuan
    if (isset($_GET['hapus'])) {
        $id = $_GET['hapus'];
        mysqli_query($koneksi, "DELETE FROM buku WHERE id='$id'");
        $_SESSION['pesan'] = "🗑️ Buku berhasil dihapus!";
        $_SESSION['tipe_pesan'] = "warning";
        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
    }

    // Tambah banyak buku (seeding)
    if (isset($_GET['seed'])) {
        $bukuList = [
            ['Laskar Pelangi', 'Andrea Hirata'],
            ['Negeri 5 Menara', 'Ahmad Fuadi'],
            ['Bumi Manusia', 'Pramoedya Ananta Toer'],
            ['Ayat-Ayat Cinta', 'Habiburrahman El Shirazy'],
            ['Koala Kumal', 'Raditya Dika'],
            ['Dilan 1990', 'Pidi Baiq'],
            ['Cantik Itu Luka', 'Eka Kurniawan'],
            ['Surat Kecil Untuk Tuhan', 'Agnes Davonar'],
            ['Sepotong Senja untuk Pacarku', 'Seno Gumira Ajidarma'],
            ['Sang Pemimpi', 'Andrea Hirata'],
            ['Ronggeng Dukuh Paruk', 'Ahmad Tohari'],
            ['Anak Semua Bangsa', 'Pramoedya Ananta Toer'],
            ['Perahu Kertas', 'Dewi Lestari'],
            ['Filosofi Kopi', 'Dewi Lestari'],
            ['Tenggelamnya Kapal Van der Wijck', 'Hamka'],
        ];

        foreach ($bukuList as $buku) {
            $cek = mysqli_query($koneksi, "SELECT * FROM buku WHERE judul='{$buku[0]}'");
            if (mysqli_num_rows($cek) == 0) {
                mysqli_query($koneksi, "INSERT INTO buku (judul, penulis) VALUES ('{$buku[0]}', '{$buku[1]}')");
            }
        }

        $_SESSION['pesan'] = "✅ 15 Buku contoh berhasil ditambahkan!";
        $_SESSION['tipe_pesan'] = "sukses";
        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
    }

    // Hapus semua buku
    if (isset($_GET['hapus_semua'])) {
        mysqli_query($koneksi, "TRUNCATE TABLE buku");
        $_SESSION['pesan'] = "🗑️ Semua buku berhasil dihapus!";
        $_SESSION['tipe_pesan'] = "warning";
        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login & Data Buku</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to right, #2563eb, #3b82f6);
            margin: 0;
            padding: 40px;
        }
        .container {
            max-width: 850px;
            margin: 0 auto;
            background: #fff;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.2);
        }
        h1 {
            text-align: center;
            color: #2563eb;
            margin-bottom: 20px;
        }
        .notif {
            padding: 12px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-weight: bold;
            text-align: center;
        }
        .notif.sukses { background: #d1fae5; color: #065f46; }
        .notif.error { background: #fee2e2; color: #991b1b; }
        .notif.warning { background: #fef3c7; color: #92400e; }

        form {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }
        form input {
            flex: 1;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 15px;
        }
        form button {
            background: #2563eb;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            font-size: 15px;
            cursor: pointer;
            font-weight: bold;
        }
        form button:hover { background: #1d4ed8; }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            background: #f9fafb;
            border-radius: 8px;
            overflow: hidden;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        th {
            background: #2563eb;
            color: white;
        }
        tr:hover { background: #eef2ff; }
        a { text-decoration: none; font-weight: bold; margin-right: 10px; }
        a.edit { color: #2563eb; }
        a.hapus { color: #dc2626; }
        a.logout { color: #fff; background:#dc2626; padding:6px 12px; border-radius:6px; }
        .btn-seed {
            background: #16a34a;
            color: white;
            padding: 8px 14px;
            border-radius: 6px;
            font-size: 14px;
        }
        .btn-seed:hover { background: #15803d; }
        .btn-delete-all {
            background: #f97316;
            color: white;
            padding: 8px 14px;
            border-radius: 6px;
            font-size: 14px;
        }
        .btn-delete-all:hover { background: #ea580c; }
    </style>
</head>
<body>

<div class="container">
    <?php if ($pesan): ?>
        <div class="notif <?= $tipe_pesan ?>">
            <?= $pesan ?>
        </div>
    <?php endif; ?>

    <?php if (!$login): ?>
        <h1>Login Admin</h1>
        <form method="POST">
            <input type="text" name="username" placeholder="Username Admin" required>
            <input type="password" name="password" placeholder="Password Admin" required>
            <button type="submit" name="login">Login</button>
        </form>
    <?php else: ?>
        <h1>📚 Manajemen Data Buku</h1>
        <p style="text-align:right">
            <a href="?seed" class="btn-seed" onclick="return confirm('Tambah banyak buku contoh?')">Tambah Banyak Buku</a>
            <a href="?hapus_semua" class="btn-delete-all" onclick="return confirm('Yakin hapus semua buku?')">Hapus Semua Buku</a>
            <a href="?logout" class="logout" onclick="return confirm('Keluar dari admin?')">Logout</a>
        </p>

        <form method="POST">
            <?php if ($edit): ?>
                <input type="hidden" name="id" value="<?= $row['id'] ?>">
            <?php endif; ?>
            <input type="text" name="judul" placeholder="Judul Buku" required value="<?= $edit ? $row['judul'] : '' ?>">
            <input type="text" name="penulis" placeholder="Penulis Buku" required value="<?= $edit ? $row['penulis'] : '' ?>">
            <button type="submit" name="<?= $edit ? 'update' : 'simpan' ?>">
                <?= $edit ? 'Update Buku' : 'Tambah Buku' ?>
            </button>
        </form>

        <table>
            <tr>
                <th>No</th>
                <th>Judul</th>
                <th>Penulis</th>
                <th>Aksi</th>
            </tr>
            <?php
            $no = 1;
            $data = mysqli_query($koneksi, "SELECT * FROM buku ORDER BY id DESC");
            while ($d = mysqli_fetch_assoc($data)) :
            ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($d['judul']) ?></td>
                <td><?= htmlspecialchars($d['penulis']) ?></td>
                <td>
                    <a href="?edit=<?= $d['id'] ?>" class="edit">Edit</a>
                    <a href="?hapus=<?= $d['id'] ?>" class="hapus" onclick="return confirm('Yakin hapus buku ini?')">Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    <?php endif; ?>
</div>

</body>
</html>